package com.cg.naukri.beans;

public class NaukriRegistration {

}
